# 02. Lean Six Sigma

Lean Six Sigma combines Lean's focus on flow and waste reduction with Six Sigma's emphasis on reducing variation and defects through data-driven problem solving.

## DMAIC at a glance

| Phase | Key question | Typical outputs |
|---|---|---|
| Define | What problem matters and to whom? | Charter, scope, VOC, high-level process |
| Measure | How does the process perform now? | Operational definitions, data plan, baseline |
| Analyse | What causes the gap? | Validated root causes, analysis |
| Improve | Which solutions address the causes? | Tested solutions, implementation plan |
| Control | How will gains be sustained? | Control plan, ownership, monitoring |

## Selecting a project

A suitable project has a meaningful performance gap, a measurable outcome, a process owner, an achievable scope and a problem that is not already solved. Avoid selecting a solution first and retrofitting a problem statement.

## Core toolset

- SIPOC and high-level process mapping
- Voice of the Customer (VOC) and Critical-to-Quality (CTQ)
- Data collection plan and operational definitions
- Pareto analysis and stratification
- Fishbone diagram and 5 Whys
- Process capability and control charts where assumptions are met
- FMEA and mistake-proofing
- Pilot design and control plan

## Worked example: reducing incomplete insurance applications

**Problem statement:** A fictional insurer observes that a material share of new applications require at least one follow-up for missing or inconsistent information. This increases handling time and delays decisions.

**Define:** Scope the process from application receipt to completeness decision. Agree customer and business outcomes.

**Measure:** Define an incomplete application consistently. Establish a representative baseline by channel, product and application type. Validate data quality.

**Analyse:** Test whether form design, intermediary training, unclear evidence requirements, system validation or channel mix explain the variation.

**Improve:** Pilot clearer instructions, proportionate front-end validation and targeted intermediary guidance. Check that controls do not create unnecessary friction or unfair exclusion.

**Control:** Monitor first-time-right rate, cycle time, abandonment, rework and complaints. Assign process ownership and escalation thresholds.

All figures in any future worked dataset should be labelled illustrative unless sourced.

## Important cautions

- Do not use statistical tests without checking data type, sampling, independence and assumptions.
- Correlation alone does not establish causation.
- Capability indices require a stable process and appropriate specification limits.
- A control chart is not simply a trend chart with limits added.
- Lean improvement must not remove controls required for safety, fairness, compliance or resilience.
