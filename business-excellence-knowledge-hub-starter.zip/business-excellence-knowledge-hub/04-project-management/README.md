# 04. Project Management

Project Management converts an approved need into a governed, deliverable change with clear outcomes, accountability and controlled risk.

## Project lifecycle

1. **Initiate:** Business case, objectives, sponsor, scope and success measures.
2. **Plan:** Deliverables, schedule, resources, budget, dependencies, risks and communications.
3. **Deliver:** Coordinate work, manage quality and engage stakeholders.
4. **Monitor and control:** Track progress, decisions, changes, issues, risks and benefits.
5. **Close and transition:** Acceptance, handover, lessons learned and benefits ownership.

## Minimum governance artefacts

- Project charter
- Stakeholder register and RACI
- Integrated plan and milestone tracker
- RAID log (risks, assumptions, issues, dependencies)
- Decision and change log
- Status report
- Benefits realisation plan
- Closure and handover checklist

## Example: claims workflow transformation

A fictional insurer plans to reduce avoidable manual handling in claims. Governance should include claims operations, customer service, technology, risk, compliance, information security, data and relevant partners. The project should define customer and control outcomes alongside efficiency targets.

## RACI reminder

R = Responsible for doing the work; A = Accountable for the outcome; C = Consulted; I = Informed. Aim for one clearly accountable role per activity wherever practical.

## Common delivery risks

- Unclear scope or success criteria
- Underestimated operational change impacts
- Insufficient process-owner capacity
- Data migration or integration dependencies
- Weak adoption and training
- Benefits claimed without a baseline or post-implementation validation

Project success is not synonymous with on-time delivery. Confirm that intended outcomes are achieved and sustained.
