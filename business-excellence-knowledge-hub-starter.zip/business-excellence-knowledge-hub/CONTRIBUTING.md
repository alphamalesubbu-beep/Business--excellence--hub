# Contributing

Thank you for helping improve the Business Excellence Knowledge Hub.

## Contribution principles

- Submit original content or material you have permission to share.
- Use clear, professional language and define specialist acronyms.
- Explain both the concept and how it can be applied.
- Distinguish established methods from personal opinion or illustrative examples.
- Cite authoritative sources when making standards, regulatory or research claims.
- Use anonymised examples. Never include customer, employee or confidential organisational data.
- Avoid reproducing copyrighted standards, paid courseware or proprietary templates.

## Suggested structure for a new guide

1. Purpose and intended audience
2. Definition and context
3. When to use / when not to use
4. Step-by-step approach
5. Roles and responsibilities
6. Example or worked scenario
7. Measures of success
8. Common pitfalls
9. References and further reading

## Pull request checklist

- [ ] The title and folder are appropriate.
- [ ] The content is accurate, readable and actionable.
- [ ] Acronyms are expanded on first use.
- [ ] Examples are fictional or properly anonymised.
- [ ] Sources are cited and links work.
- [ ] No confidential, personal or copyrighted restricted content is included.
- [ ] Any template includes instructions and version/date information.

## Reporting an issue

Open an issue describing the topic, the gap or error, the intended audience and the improvement you recommend. Please do not include sensitive information.
