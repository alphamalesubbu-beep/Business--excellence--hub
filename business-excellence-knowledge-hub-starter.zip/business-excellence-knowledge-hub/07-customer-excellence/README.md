# 07. Customer Excellence

Customer Excellence designs and improves experiences around customer needs, expectations, effort, trust and outcomes across the full journey.

## Core practices

- Voice of the Customer (VOC)
- Customer segmentation and needs analysis
- Journey mapping and service blueprinting
- Critical-to-Quality (CTQ) translation
- Complaint and feedback analysis
- Accessibility and inclusive service design
- Closed-loop feedback and service recovery

## From feedback to improvement

1. Collect feedback through appropriate channels.
2. Combine stated feedback with behavioural and operational evidence.
3. Segment results carefully; avoid overgeneralising from small samples.
4. Identify moments that matter and sources of customer effort.
5. Prioritise issues by customer harm, frequency, severity and strategic relevance.
6. Test changes with customers and frontline teams.
7. Close the loop and monitor whether outcomes improve.

## Example: claims communication

Customers may experience uncertainty while a claim is being assessed. A journey review could examine status visibility, clarity of evidence requests, expected timeframes, accessibility, escalation routes and consistency across digital and human channels. Improving communication may reduce avoidable contacts even where the underlying assessment time cannot immediately change.

## Metrics and cautions

Possible measures include complaints per relevant volume, repeat contact, customer effort, satisfaction, resolution at first contact and journey abandonment. NPS, CSAT and effort scores each have limitations; interpret them with qualitative feedback and operational data. Never use survey scores as the sole measure of customer fairness or service quality.
