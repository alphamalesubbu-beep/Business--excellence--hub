# 03. Quality Management

Quality Management provides the policies, processes, responsibilities and assurance mechanisms used to consistently meet requirements and improve customer and stakeholder outcomes.

## Quality Management System (QMS)

A practical QMS connects:

1. Organisational context and interested parties
2. Leadership, quality policy and responsibilities
3. Risk-based planning and quality objectives
4. Competence, awareness, communication and documented information
5. Operational planning and process controls
6. Monitoring, measurement, audit and management review
7. Nonconformity, corrective action and continual improvement

## ISO 9001

ISO 9001 is an internationally recognised standard for quality management systems. This repository provides explanatory learning notes only; it does not reproduce the standard. Consult the current official publication and applicable certification-body guidance for requirements.

## Nonconformity and corrective action

A disciplined corrective-action workflow:

1. Contain the immediate issue and protect the customer.
2. Record the requirement that was not met and objective evidence.
3. Assess extent: isolated event or wider systemic exposure?
4. Investigate causes using evidence and process understanding.
5. Select actions that address causes, not only symptoms.
6. Implement with owners and due dates.
7. Verify effectiveness after a suitable period and sample.
8. Update risks, controls, training and documented information where needed.

## Example: recurring policy issuance errors

A quality review finds recurring errors in policy schedules. The response should not stop at reminding processors to be careful. Examine source-data quality, product-rule configuration, screen design, hand-offs, review controls and workload. Track error rate, severity, rework and customer impact.

## Quality audit good practice

- Define objective, scope, criteria and audit method.
- Use competent, impartial auditors.
- Sample based on risk and process significance.
- Record objective evidence and trace findings to criteria.
- Distinguish nonconformity, observation and improvement opportunity.
- Follow up corrective action and effectiveness.

## Measures

First-time-right, defect rate, rework hours, complaint recurrence, corrective-action ageing, audit finding recurrence and customer-impact severity.
