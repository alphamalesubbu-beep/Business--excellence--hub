# Business Excellence Knowledge Hub

> **Transforming Processes. Elevating Performance. Creating Excellence.**

A practical, cross-industry knowledge repository for professionals who design, lead and sustain improvements in organisational performance. It brings together Business Excellence frameworks, Lean Six Sigma, Quality Management, Project Management, Process Excellence, Performance Management and Customer Excellence—with examples from insurance and financial services as well as other sectors.

[![Status](https://img.shields.io/badge/status-active%20development-blue)]()
[![Focus](https://img.shields.io/badge/focus-business%20excellence-0A7EA4)]()
[![Content](https://img.shields.io/badge/content-practical%20guides%20%7C%20templates%20%7C%20cases-success)]()

## What you will find

| Domain | What it covers |
|---|---|
| [01. Business Excellence](01-business-excellence/README.md) | Excellence principles, EFQM, Baldrige, maturity and self-assessment |
| [02. Lean Six Sigma](02-lean-six-sigma/README.md) | DMAIC, Lean thinking, statistical tools and problem solving |
| [03. Quality Management](03-quality-management/README.md) | QMS, ISO 9001 concepts, audits, CAPA and risk-based thinking |
| [04. Project Management](04-project-management/README.md) | Initiation, planning, governance, delivery and benefits realisation |
| [05. Process Excellence](05-process-excellence/README.md) | Process architecture, mapping, VSM, redesign and automation |
| [06. Performance Management](06-performance-management/README.md) | KPIs, scorecards, targets, dashboards and review rhythms |
| [07. Customer Excellence](07-customer-excellence/README.md) | VOC, journey mapping, service quality, complaints and experience |
| [08. Templates & Case Studies](08-templates-and-case-studies/README.md) | Reusable working documents and illustrative case studies |

## How to use this repository

1. **Learn:** Start with the domain overview and methodology guides.
2. **Apply:** Adapt the templates to your organisation, controls and regulatory environment.
3. **Measure:** Define baseline, target, owner, frequency and evidence before launching an initiative.
4. **Sustain:** Build control plans, management reviews and benefit tracking into the solution.
5. **Share:** Suggest improvements through issues or pull requests.

## Core improvement lifecycle

A practical improvement cycle connects strategy to measurable outcomes:

1. **Align:** Clarify customer needs, strategic priorities and the problem to solve.
2. **Understand:** Map the current state and establish a reliable baseline.
3. **Diagnose:** Validate root causes using evidence rather than assumptions.
4. **Improve:** Design, test and implement solutions with process owners.
5. **Control:** Monitor outcomes, manage exceptions and sustain the gains.
6. **Learn:** Capture lessons and identify the next opportunity.

## Cross-industry perspective

The principles in this repository apply to manufacturing, insurance, banking, healthcare, education, technology, shared services, public services and other operating environments.

Examples may use insurance and financial services scenarios—such as policy issuance, claims, underwriting, contact centres, onboarding, KYC, complaints and payment operations. These are illustrative learning examples, not legal, regulatory or actuarial advice.

## Repository principles

- **Evidence-led:** Separate facts, hypotheses, assumptions and decisions.
- **Customer-centred:** Evaluate impact on customer outcomes, not only internal efficiency.
- **Process-oriented:** Improve end-to-end value streams rather than isolated functions.
- **Risk-aware:** Consider compliance, operational resilience, privacy and control requirements.
- **People-inclusive:** Involve frontline teams and process owners in diagnosis and design.
- **Sustainable:** Define ownership and controls so improvements endure.

## Suggested learning path

| Stage | Recommended starting point |
|---|---|
| Foundation | Business Excellence principles and process thinking |
| Problem solving | DMAIC and root-cause analysis |
| Process discipline | Quality Management and CAPA |
| Delivery | Project Management and governance |
| Measurement | KPI design and performance reviews |
| Experience | VOC and customer journey mapping |
| Application | Templates and case studies |

## Contributing

Contributions are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md). Use anonymised, non-confidential examples only. Do not upload customer data, personal information, proprietary company material or restricted documents.

## Disclaimer

This repository is for general educational and professional development purposes. It is not a substitute for applicable standards, licensed publications, legal advice, regulatory guidance or organisation-specific policies. Standards and regulatory requirements change; verify current authoritative sources before implementation. Framework names and trademarks remain the property of their respective owners.

## Licence

Unless otherwise stated, original written content in this repository is made available under the [Creative Commons Attribution 4.0 International licence](LICENSE). Third-party names, marks and referenced materials remain subject to their owners' terms.
