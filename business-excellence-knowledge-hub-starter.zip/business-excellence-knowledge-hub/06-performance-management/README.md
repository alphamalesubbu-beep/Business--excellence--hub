# 06. Performance Management

Performance Management translates strategy into a balanced set of outcomes, measures, targets, ownership and management actions.

## Build a useful KPI

For each KPI, document:

- Name and purpose
- Strategic objective and intended behaviour
- Formula and unit
- Numerator, denominator and exclusions
- Data source, refresh frequency and owner
- Baseline, target and tolerance
- Segmentation and interpretation guidance
- Known limitations and potential unintended consequences

## Leading and lagging indicators

- **Lagging:** Outcomes already realised, such as complaint rate or operating cost.
- **Leading:** Signals that may influence future outcomes, such as training completion or quality checks. A leading indicator must be tested; it is not automatically predictive.

## Balanced scorecard perspectives

A balanced view commonly considers financial, customer, internal process, and learning/capability outcomes. Adapt the perspectives to organisational purpose and stakeholders.

## Example: claims operations scorecard

| Perspective | Illustrative measure |
|---|---|
| Customer | Customer effort or post-claim satisfaction |
| Process | End-to-end claim cycle time |
| Quality | First-time-right decision rate |
| Risk | Material control exceptions |
| People | Competency and workload indicators |
| Financial | Cost per completed claim |

Avoid managing to one metric in isolation. For example, reducing average cycle time may conceal a growing backlog of complex claims.

## Review rhythm

- Daily/weekly: operational exceptions and blockers
- Monthly: trend, root causes, corrective actions and capacity
- Quarterly: strategic outcomes, assumptions and portfolio priorities

A dashboard should prompt decisions. If a metric has no owner, interpretation, threshold or action path, it may be reporting rather than management.
