# 05. Process Excellence

Process Excellence improves end-to-end workflows so that they deliver customer value with appropriate quality, speed, cost, control and resilience.

## Start with the process

Define the trigger, start and end points, customer, output, process owner, upstream inputs and downstream users. Distinguish the end-to-end value stream from an individual team's activities.

## Mapping hierarchy

- **SIPOC:** Suppliers, Inputs, Process, Outputs, Customers; useful for agreeing scope.
- **High-level map:** Major stages and hand-offs.
- **Swimlane map:** Roles, systems, decisions and transfers.
- **Value Stream Map (VSM):** Material/information flow, waiting, processing and constraints.
- **Detailed procedure:** Task-level instructions and controls.

## Improvement sequence

1. Confirm customer need and process boundaries.
2. Observe actual work; do not rely only on documented procedures.
3. Capture volumes, demand patterns, queues, rework and exceptions.
4. Identify waste, bottlenecks, failure points and control requirements.
5. Design a future state with process owners and users.
6. Pilot, measure and refine.
7. Update procedures, systems, training and controls.
8. Monitor process health and customer outcomes.

## Example: customer onboarding

A financial-services onboarding process may include application, identity verification, risk assessment, exception handling and activation. Mapping should show customer wait time, internal touch time, third-party dependencies, rework loops and required control gates. Faster onboarding is not an improvement if it weakens due diligence or creates downstream remediation.

## Measures

End-to-end cycle time, touch time, queue time, throughput, first-time-right, rework, abandonment, exception rate and control failure rate.

## Automation principle

Stabilise and simplify before automating. Automating a fragmented process can make defects faster and harder to detect.
