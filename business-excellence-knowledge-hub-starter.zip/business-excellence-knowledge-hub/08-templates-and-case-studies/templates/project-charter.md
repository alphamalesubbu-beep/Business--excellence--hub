# Project Charter Template

> Complete this charter with the sponsor and process owner before detailed planning.

## 1. Project overview

| Field | Entry |
|---|---|
| Project title | |
| Sponsor | |
| Project manager | |
| Process owner | |
| Date / version | |
| Status | |

## 2. Business need and problem statement

Describe the gap between current and required performance. Include who is affected, where it occurs, when it occurs and why it matters. Avoid embedding an untested solution.

## 3. Objectives and success measures

| Outcome | Baseline | Target | Measure / source | Due date |
|---|---:|---:|---|---|
| | | | | |

## 4. Scope

**In scope:**  
**Out of scope:**  
**Start and end points:**  

## 5. Deliverables and milestones

| Deliverable | Owner | Due date | Acceptance criteria |
|---|---|---|---|
| | | | |

## 6. Stakeholders and governance

| Role / group | Responsibility | Engagement approach |
|---|---|---|
| Sponsor | | |
| Process owner | | |
| Delivery team | | |
| Risk / compliance / control partners | | |

## 7. Key assumptions, constraints and dependencies

- Assumptions:
- Constraints:
- Dependencies:

## 8. Initial risks

| Risk | Impact | Mitigation / response | Owner |
|---|---|---|---|
| | | | |

## 9. Benefits and transition

Define benefit owner, measurement method, timing, handover requirements and post-implementation review date.

## 10. Approval

| Approver | Name | Decision | Date |
|---|---|---|---|
| Sponsor | | | |
| Process owner | | | |
