# Problem-Solving A3 Template

## 1. Background and business context

Why does this issue matter now? Link it to customer, operational, strategic or risk outcomes.

## 2. Current condition

Describe the process and show evidence. State the baseline period, population, definitions and data limitations.

## 3. Problem statement

Write a specific, measurable statement of the gap. Do not state a preferred solution.

## 4. Target condition

Define the desired outcome, measure, target and time horizon.

## 5. Root-cause analysis

List candidate causes, evidence gathered and tests performed. Separate verified causes from hypotheses.

| Candidate cause | Evidence / test | Finding |
|---|---|---|
| | | |

## 6. Countermeasures

| Root cause addressed | Countermeasure | Owner | Due date |
|---|---|---|---|
| | | | |

## 7. Implementation plan

Include pilot scope, stakeholder involvement, training, controls, communication and change impacts.

## 8. Results and follow-up

Compare baseline and post-change results using consistent definitions. Note unintended consequences and remaining gaps.

## 9. Control and learning

Define process owner, monitoring frequency, reaction plan, standard work updates and lessons learned.
