# Risk and Issue Log

Use one row per risk or issue. Define the organisation's scoring scale before use.

| ID | Type (Risk/Issue) | Description | Cause | Impact | Likelihood | Severity | Response / action | Owner | Due date | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| R-001 | Risk | | | | | | | | | Open |
| I-001 | Issue | | | | | | | | | Open |

## Guidance

- A **risk** is an uncertain future event or condition.
- An **issue** is a situation that has already occurred and needs action.
- Record dependencies and escalation triggers where relevant.
- Review regularly and retain a decision trail.
- Do not place sensitive customer, employee or security information in a public repository.
