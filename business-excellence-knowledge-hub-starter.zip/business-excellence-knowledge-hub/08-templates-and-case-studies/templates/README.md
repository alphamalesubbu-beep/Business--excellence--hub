# Templates

Reusable starting points: [Project Charter](project-charter.md), [Problem-Solving A3](problem-solving-a3.md), [KPI Definition Sheet](kpi-definition-sheet.md), and [Risk and Issue Log](risk-issue-log.md).
