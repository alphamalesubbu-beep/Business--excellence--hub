# KPI Definition Sheet

| Field | Definition |
|---|---|
| KPI name | |
| Strategic objective | |
| Purpose / decision supported | |
| KPI owner | |
| Formula | |
| Numerator | |
| Denominator | |
| Unit | |
| Inclusion / exclusion rules | |
| Data source / system | |
| Refresh frequency | |
| Baseline and period | |
| Target / tolerance | |
| Segmentation | |
| Interpretation notes | |
| Known limitations | |
| Potential unintended behaviour | |
| Escalation / action when off-track | |
| Definition version / effective date | |

## Quality checks

- Is the measure clearly defined and reproducible?
- Does it measure an outcome or a meaningful driver?
- Can the data be validated and reconciled?
- Are exclusions and denominator rules explicit?
- Could the target encourage undesirable behaviour?
- Is there a named owner and an action when performance changes?
