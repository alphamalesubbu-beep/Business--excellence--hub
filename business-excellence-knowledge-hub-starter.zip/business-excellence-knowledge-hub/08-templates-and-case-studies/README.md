# 08. Templates & Case Studies

This area contains reusable starting points and fictional case studies. Adapt each artefact to your organisation's governance, technology, risk appetite and regulatory obligations.

## Starter templates

- [Project Charter](templates/project-charter.md)
- [Problem-Solving A3](templates/problem-solving-a3.md)
- [KPI Definition Sheet](templates/kpi-definition-sheet.md)
- [Risk and Issue Log](templates/risk-issue-log.md)

## Case studies

- [Reducing incomplete insurance applications](case-studies/reducing-incomplete-applications.md)

## Template use guidance

Before using a template:
1. Confirm the purpose and accountable owner.
2. Tailor fields to the process and decision being supported.
3. Define evidence, data sources and approval requirements.
4. Remove fields that do not support a decision.
5. Store completed records in approved organisational systems.

All examples in this starter release are fictional and for learning purposes.
