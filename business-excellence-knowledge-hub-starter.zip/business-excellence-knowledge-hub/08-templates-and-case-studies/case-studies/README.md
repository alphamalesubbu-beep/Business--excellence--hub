# Case Studies

[Fictional case: Reducing incomplete applications](reducing-incomplete-applications.md). All scenarios are illustrative and contain no real customer or company data.
