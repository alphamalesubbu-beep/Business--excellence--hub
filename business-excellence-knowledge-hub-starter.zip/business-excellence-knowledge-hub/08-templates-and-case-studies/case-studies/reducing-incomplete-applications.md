# Case Study: Reducing Incomplete Applications

**Illustrative fictional scenario**

## Context

A fictional multi-channel insurer experiences repeated follow-ups because a portion of new business applications arrive with missing or inconsistent information. The resulting rework affects customers, intermediaries and operations teams.

## Objective

Improve application completeness at first submission without weakening underwriting, identity, fraud or regulatory controls.

## Approach

### Define
Agree the start and end points, customer impact, scope, sponsor and process owner. Define what counts as an incomplete application.

### Measure
Establish a baseline using a representative period. Segment by product, channel, intermediary and missing-information category. Validate source-system coding and avoid double-counting resubmissions.

### Analyse
Use Pareto analysis to identify common missing fields. Interview frontline teams and intermediaries. Examine form wording, guidance, system validation, hand-offs and exception paths. Validate causes with evidence.

### Improve
Pilot plain-language instructions, contextual prompts, proportionate validation and targeted intermediary support. Test accessibility and ensure customers are not unfairly blocked by digital-only controls.

### Control
Track first-time-right, rework, end-to-end cycle time, abandonment, complaints and control exceptions. Assign owners and review unintended effects.

## Example measurement plan

| Measure | Why it matters |
|---|---|
| First-time-right application rate | Core completeness outcome |
| Follow-up requests per application | Rework and customer effort |
| Application abandonment | Potential friction or exclusion |
| Decision cycle time | End-to-end service impact |
| Control exception rate | Guardrail against weakened controls |

## Lessons

- Define the measure before collecting data.
- Segment the process to avoid treating all channels and products as identical.
- Do not assume training is the root cause.
- Pair speed and completeness measures with customer and control guardrails.
- Treat the pilot as a test; validate results before scaling.

No performance figures are asserted in this fictional case study.
